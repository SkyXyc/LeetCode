package problem1to10;

public class Problem8 {
    public int myAtoi(String str) {
        int sum = 0;
        for(int i=0;i<=str.length()-1;i++){
            int x = (int)str.charAt(i)-48;
            System.out.println(str.charAt(i) +" "+x);
            sum = sum*10 + x; 
        }
        return sum;
    }
    
    public static void main(String[] args){
    	Problem8 problem8 = new Problem8();
    	System.out.println(problem8.myAtoi("654"));
    }
}
