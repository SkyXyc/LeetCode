package problem1to10;

import java.util.HashMap;
import java.util.Map;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;

public class Problem3 {
    public int lengthOfLongestSubstring(String s) {
    	int max = 0;
        int start = 0;
        char ch;
        Map<Character,Integer> map = new HashMap<>(s.length());
        while(start<s.length()){
        	for(int i=start;i<s.length();i++){
                ch = s.charAt(i);
                System.out.println(ch);
                if(!map.containsValue(ch)){
                	System.out.println("yicunzai");
                	map.put(ch, i);
                if((map.containsKey(ch))){
                	
                	if((i-start+1)>max){
                		max = i-start+1;
                	}
                	start++;
                	break;
                }
              
            }
        	start++;
        }
        
        
    }
		return max;
    }
    
    public int lengthOfLongestSubstring1(String s) {
        // 字符串输入不合法
        if (s == null) {
            return 0;
        }

        // 当前处理的开始位置
        int start = 0;
        // 记录到的最大非重复子串长度
        int result = 0;
        // 访问标记，记录最新一次访问的字符和位置
        Map<Character, Integer> map = new HashMap<>(s.length());

        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            // 如果字符已经出现过(在标记开位置算起)，就重新标记start
            if (map.containsKey(ch) && map.get(ch) >= start) {
                start = map.get(ch) + 1;
            }
            // 如果没有出现过就求最大的非重复子串的长度
            else {
                result = Math.max(result, i - start + 1);
                System.out.println(result+" "+ch+" "+start);
            }

            // 更新访问记录
            map.put(ch, i);
        }
        return result;
    }
    
    public static void main(String[] args){
    	Problem3 problem3 = new Problem3();
    	System.out.println(problem3.lengthOfLongestSubstring1("babc"));
    }
}
