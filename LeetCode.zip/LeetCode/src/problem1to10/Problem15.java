package problem1to10;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Problem15 {
	 /**
	  * Problem 15
	  * @param nums 输入是n维的int型数组
	  * @return 输出是int型List，其中元素为大小为3的int型list，这三个数字的和为0
	  */
	 public static List<List<Integer>> threeSum0(int[] nums) {//这种方法不能剔除重复的元组，一种方法是先排序。
		 	List<List<Integer>> result = new ArrayList<List<Integer>>();
	        int num = nums.length;
	        for(int i=0;i<num;i++){
	        	for(int j=i+1;j<num;j++){
	        		for(int k=j+1;k<num;k++){
	        			if(nums[i]+nums[j]+nums[k]==0){
	        				List<Integer> res = new ArrayList<Integer>();
	        				res.add(nums[i]);
	        				res.add(nums[j]);
	        				res.add(nums[k]);
	        				result.add(res);
	        			}
	        		}
	        	}
	        }
	        return result;
	    }
	 
	 public static List<List<Integer>> threeSum(int[] nums) {
		 	List<List<Integer>> result = new ArrayList<List<Integer>>();
	        int length = nums.length;
	        int negative = 0;
	        int positive = length-1;
	        
	        if(length>2){
	        	nums = sort(nums);
	        }
	        
	        while(nums[negative]<0){
	        	
	        	if((negative!=0)&&(nums[negative]==nums[negative-1])){
	        		negative++;
	        		continue;
	        	}
	        	
	        	while(nums[positive]>0){
	        		Set<Integer> set = new HashSet<Integer>();
	        		for(int i=negative;i<positive;i++){
	        			if(nums[i]==(-nums[negative]-nums[positive])){
	        				set.add(nums[i]);
	        			}
	        		}
	        		
	        		for(Integer k:set){
        				List<Integer> res = new ArrayList<Integer>();
        				res.add(nums[negative]);
        				res.add(k);
        				res.add(nums[positive]);
        				result.add(res);
        			}
	        		
	        		if(nums[positive]==nums[positive-1]){
	        			while(nums[positive]==nums[positive-1]){
		        			positive--;
		        		}
	        		}else{
	        			positive--;
	        		}
	        	}
	        	
	        	if((negative!=0)&&(nums[negative]==nums[negative-1])){
        			while(nums[negative]==nums[negative-1]){
        				negative++;
	        		}
        		}else{
        			negative++;
        		}
	        	
	        	positive = length-1;
	        }
	        
	        return result;
	    }
	 
	 public static int[] sort(int[] nums){//冒泡排序
		 int num = nums.length;
		 int temp;
		 for(int i=0;i<num;i++){
			 for(int j=i+1;j<num;j++){
				 if(nums[i]>=nums[j]){
					 temp = nums[i];
					 nums[i] = nums[j];
					 nums[j] = temp;
				 }
			 }
		 }
		 return nums;
	 }
	 
	 public static void main(String[] args){
		 int[] nums1 = {1, 0, 1, 2, -1, -4};
		 int[] nums2 = {-8,-6,-3,0,2,4,1,5,3,3,3,3};
		 List<List<Integer>> result = threeSum(nums1);
		 for(List<Integer> res:result){
			 for(Integer s:res){
				 System.out.print(s + " ");
			 }
			 System.out.println();
		 }
		 System.out.println();
		
	 }
}
