package problem1to10;

import java.util.HashMap;
import java.util.Map;

public class Problem3_1 {
    public int lengthOfLongestSubstring(String s) {
    	if(s==null){
    		
    	}
        Map<Character,Integer> map = new HashMap<Character,Integer>(s.length());
        int start = 0;
        int max = 0;
        int result = 0;
        char ch;
        for(int i=0;i<s.length();i++){
        	ch = s.charAt(i);
            if(map.containsKey(ch)){
            	start = map.get(ch)+1;
            	System.out.println(start+" "+ch);
            }else{
            	result = Math.max(result, i-start+1);
            	System.out.println("resule1: "+result);
            }
        map.put(ch, i);    
        }
        return result;    
        }
    
    public static void main(String[] args){
    	Problem3_1 problem3_1 = new Problem3_1();
    	int re = problem3_1.lengthOfLongestSubstring("tmmzuxt");
    	System.out.println("result:"+re);
    }
}
