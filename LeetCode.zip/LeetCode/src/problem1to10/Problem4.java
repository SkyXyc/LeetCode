package problem1to10;

public class Problem4 {//待做，使用类二分查找（或转化为两个数组找第k小的数）
	/**
	 * 查找两个已排序数组的中位数
	 * @param nums1 数组1
	 * @param nums2 数组2
	 * @return
	 */
	public double findMedianSortedArrays(int[] nums1, int[] nums2) {
        double result = 0;
        
        
        
        return result;
    }
}
