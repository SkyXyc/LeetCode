package problem1to10;

public class Problem20 {

}
