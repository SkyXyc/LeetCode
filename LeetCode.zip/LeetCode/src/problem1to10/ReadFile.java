package problem1to10;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;



public class ReadFile {
	public static String[][] sourcedata = new String[101767][45];
	public static Vector<double[]> data = new Vector<double[]>();
	public static Vector<double[]> init_kernal = new Vector<double[]>();
	static java.text.DecimalFormat   df   =new   java.text.DecimalFormat("#.00");  
	
	//从文件里读数据
	public static String[][] loadData(String filePath)
	{
		 int i=0;
		 String[] str = null;
		 try {
			 File file = new File(filePath);
			 if(file.isFile() && file.exists()) {
		     InputStreamReader isr = new InputStreamReader(new FileInputStream(file), "utf-8");
		     BufferedReader br = new BufferedReader(isr);
		     String lineTxt = null;
		     while ((lineTxt = br.readLine()) != null) 
		     {
		    	 str = lineTxt.split(",");
		    	 for(int k=0;k<str.length;k++)
		    	 {
		    		 sourcedata[i][k] = str[k];
		    	 }
		    	 i++;
		    	 System.out.println("已读取第"+i+"条数据");
		       }
		       br.close();
		     }else {
		    	 System.out.println("文件不存在!");
		     }
		  	} catch (Exception e) {
		  		System.out.println("文件读取错误!");
		  	}
		return sourcedata;

	}
	
	
	//数据初始化
	public static void preparement(String[][] sourcedata)
	{
		//给每个string字符串赋整形数值
		// 5 10 18 19 20 不要！！
		for(int q=0;q<sourcedata.length;q++)
	     {
	    	 for(int l=0;l<sourcedata[q].length;l++)
	    	 {
	    		 if(l==2)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "Caucasian":sourcedata[q][l]="1";break;
	    			 	case "AfricanAmerican":sourcedata[q][l]="2";break;
	    			 	case "Other":sourcedata[q][l]="3";break;
	    			 	case "Asian":sourcedata[q][l]="4";break;
	    			 	case "Hispanic":sourcedata[q][l]="5";break;
	    			 	case "?":sourcedata[q][l]="0";break;
					}
	    		 }else if(l==3)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "Unknown/Invalid":sourcedata[q][l]="-1";break;
	    			 	case "?":sourcedata[q][l]="0";break;
	    			 	case "Female":sourcedata[q][l]="1";break;
	    			 	case "Male":sourcedata[q][l]="2";break;
	    			 	
	    			 	
					}
	    		 }else if(l==4)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "[0-10)":sourcedata[q][l]="1";break;
	    			 	case "[10-20)":sourcedata[q][l]="2";break;
	    			 	case "[20-30)":sourcedata[q][l]="3";break;
	    			 	case "[30-40)":sourcedata[q][l]="4";break;
	    			 	case "[40-50)":sourcedata[q][l]="5";break;
	    			 	case "[50-60)":sourcedata[q][l]="6";break;
	    			 	case "[60-70)":sourcedata[q][l]="7";break;
	    			 	case "[70-80)":sourcedata[q][l]="8";break;
	    			 	case "[80-90)":sourcedata[q][l]="9";break;
	    			 	case "[90-100)":sourcedata[q][l]="10";break;
					}
	    		 }else if(l==9)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "?":sourcedata[q][l]="0";break;
	    			 	case "AllergyandImmunology":sourcedata[q][l]="1";break;
	    			 	case "Anesthesiology":sourcedata[q][l]="2";break;
	    			 	case "Anesthesiology-Pediatric":sourcedata[q][l]="3";break;
	    			 	case "Cardiology":sourcedata[q][l]="4";break;
	    			 	case "Cardiology-Pediatric":sourcedata[q][l]="5";break;
	    			 	case "DCPTEAM":sourcedata[q][l]="6";break;
	    			 	case "Dentistry":sourcedata[q][l]="7";break;
	    			 	case "Dermatology":sourcedata[q][l]="8";break;
	    			 	case "Emergency/Trauma":sourcedata[q][l]="9";break;
	    			 	case "Endocrinology":sourcedata[q][l]="10";break;
	    			 	case "Endocrinology-Metabolism":sourcedata[q][l]="11";break;
	    			 	case "Family/GeneralPractice":sourcedata[q][l]="12";break;
	    			 	case "Gastroenterology":sourcedata[q][l]="13";break;
	    			 	case "Gynecology":sourcedata[q][l]="14";break;
	    			 	case "Hematology":sourcedata[q][l]="15";break;
	    			 	case "Hematology/Oncology":sourcedata[q][l]="16";break;
	    			 	case "Hospitalist":sourcedata[q][l]="17";break;
	    			 	case "InfectiousDiseases":sourcedata[q][l]="18";break;
	    			 	case "InternalMedicine":sourcedata[q][l]="19";break;
	    			 	case "Nephrology":sourcedata[q][l]="20";break;
	    			 	case "Neurology":sourcedata[q][l]="21";break;
	    			 	case "Neurophysiology":sourcedata[q][l]="22";break;
	    			 	case "Obsterics&Gynecology-GynecologicOnco":sourcedata[q][l]="23";break;
	    			 	case "Obstetrics":sourcedata[q][l]="24";break;
	    			 	case "ObstetricsandGynecology":sourcedata[q][l]="25";break;
	    			 	case "Oncology":sourcedata[q][l]="26";break;
	    			 	case "Ophthalmology":sourcedata[q][l]="27";break;
	    			 	case "Orthopedics":sourcedata[q][l]="28";break;
	    			 	case "Orthopedics-Reconstructive":sourcedata[q][l]="29";break;
	    			 	case "Osteopath":sourcedata[q][l]="30";break;
	    			 	case "Otolaryngology":sourcedata[q][l]="31";break;
	    			 	case "OutreachServices":sourcedata[q][l]="32";break;
	    			 	case "Pathology":sourcedata[q][l]="33";break;
	    			 	case "Pediatrics":sourcedata[q][l]="34";break;
	    			 	case "Pediatrics-AllergyandImmunology":sourcedata[q][l]="35";break;
	    			 	case "Pediatrics-CriticalCare":sourcedata[q][l]="36";break;
	    			 	case "Pediatrics-EmergencyMedicine":sourcedata[q][l]="37";break;
	    			 	case "Pediatrics-Endocrinology":sourcedata[q][l]="38";break;
	    			 	case "Pediatrics-Hematology-Oncology":sourcedata[q][l]="39";break;
	    			 	case "Pediatrics-InfectiousDiseases":sourcedata[q][l]="40";break;
	    			 	case "Pediatrics-Neurology":sourcedata[q][l]="41";break;
	    			 	case "Pediatrics-Pulmonology":sourcedata[q][l]="42";break;
	    			 	case "Perinatology":sourcedata[q][l]="43";break;
	    			 	case "PhysicalMedicineandRehabilitation":sourcedata[q][l]="44";break;
	    			 	case "PhysicianNotFound":sourcedata[q][l]="45";break;
	    			 	case "Podiatry":sourcedata[q][l]="46";break;
	    			 	case "Proctology":sourcedata[q][l]="47";break;
	    			 	case "Psychiatry":sourcedata[q][l]="48";break;
	    			 	case "Psychiatry-Addictive":sourcedata[q][l]="49";break;
	    			 	case "Psychiatry-Child/Adolescent":sourcedata[q][l]="50";break;
	    			 	case "Psychology":sourcedata[q][l]="51";break;
	    			 	case "Pulmonology":sourcedata[q][l]="52";break;
	    			 	case "Radiologist":sourcedata[q][l]="53";break;
	    			 	case "Radiology":sourcedata[q][l]="54";break;
	    			 	case "Resident":sourcedata[q][l]="55";break;
	    			 	case "Rheumatology":sourcedata[q][l]="56";break;
	    			 	case "Speech":sourcedata[q][l]="57";break;
	    			 	case "SportsMedicine":sourcedata[q][l]="58";break;
	    			 	case "Surgeon":sourcedata[q][l]="59";break;
	    			 	case "Surgery-Cardiovascular":sourcedata[q][l]="60";break;
	    			 	case "Surgery-Cardiovascular/Thoracic":sourcedata[q][l]="61";break;
	    			 	case "Surgery-Colon&Rectal":sourcedata[q][l]="62";break;
	    			 	case "Surgery-General":sourcedata[q][l]="63";break;
	    			 	case "Surgery-Maxillofacial":sourcedata[q][l]="64";break;
	    			 	case "Surgery-Neuro":sourcedata[q][l]="65";break;
	    			 	case "Surgery-Pediatric":sourcedata[q][l]="66";break;
	    			 	case "Surgery-Plastic":sourcedata[q][l]="67";break;
	    			 	case "Surgery-PlasticwithinHeadandNeck":sourcedata[q][l]="68";break;
	    			 	case "Surgery-Thoracic":sourcedata[q][l]="69";break;
	    			 	case "Surgery-Vascular":sourcedata[q][l]="70";break;
	    			 	case "SurgicalSpecialty":sourcedata[q][l]="71";break;
	    			 	case "Urology":sourcedata[q][l]="72";break;
	    			 	
	    			 	
					}
	    		 }else if(l==17)
	    		 {   //No--0  Steady--1 Down--2 Up--3 None--4
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "None":sourcedata[q][l]="0";break;
	    			 	case "Norm":sourcedata[q][l]="1";break;
	    			 	case ">200":sourcedata[q][l]="2";break;
	    			 	case ">300":sourcedata[q][l]="3";break;
					} 
	    		 }else if(l==18)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "None":sourcedata[q][l]="0";break;
	    			 	case "Norm":sourcedata[q][l]="1";break;
	    			 	case ">7":sourcedata[q][l]="2";break;
	    			 	case ">8":sourcedata[q][l]="3";break;
					}
	    		 }else if(l==19)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
	    			 	case "Down":sourcedata[q][l]="2";break;
	    			 	case "Up":sourcedata[q][l]="3";break;
					} 
	    		 }else if(l==20)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
	    			 	case "Down":sourcedata[q][l]="2";break;
	    			 	case "Up":sourcedata[q][l]="3";break;
					} 
	    		 }else if(l==21)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
	    			 	case "Down":sourcedata[q][l]="2";break;
	    			 	case "Up":sourcedata[q][l]="3";break;
					} 
	    		 }else if(l==22)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
	    			 	case "Down":sourcedata[q][l]="2";break;
	    			 	case "Up":sourcedata[q][l]="3";break;
					} 
	    		 }else if(l==23)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
	    			 	case "Down":sourcedata[q][l]="2";break;
	    			 	case "Up":sourcedata[q][l]="3";break;
					} 
	    		 }else if(l==24)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
					} 
	    		 }else if(l==25)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
	    			 	case "Down":sourcedata[q][l]="2";break;
	    			 	case "Up":sourcedata[q][l]="3";break;
					} 
	    		 }else if(l==26)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
	    			 	case "Down":sourcedata[q][l]="2";break;
	    			 	case "Up":sourcedata[q][l]="3";break;
					} 
	    		 }else if(l==27)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
					} 
	    		 }else if(l==28)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
	    			 	case "Down":sourcedata[q][l]="2";break;
	    			 	case "Up":sourcedata[q][l]="3";break;
					} 
	    		 }else if(l==29)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
	    			 	case "Down":sourcedata[q][l]="2";break;
	    			 	case "Up":sourcedata[q][l]="3";break;
					} 
	    		 }else if(l==30)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
	    			 	case "Down":sourcedata[q][l]="2";break;
	    			 	case "Up":sourcedata[q][l]="3";break;
					} 
	    		 }else if(l==31)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
	    			 	case "Down":sourcedata[q][l]="2";break;
	    			 	case "Up":sourcedata[q][l]="3";break;
					} 
	    		 }else if(l==32)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
					} 
	    		 }else if(l==33)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
	    			 	case "Up":sourcedata[q][l]="2";break;
					} 
	    		 }else if(l==34)
	    		 {
	    			 sourcedata[q][l]="0";
	    		 }else if(l==35)
	    		 {
	    			 sourcedata[q][l]="0";
	    		 }else if(l==36)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
	    			 	case "Down":sourcedata[q][l]="2";break;
	    			 	case "Up":sourcedata[q][l]="3";break;
					} 
	    		 }else if(l==37)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
	    			 	case "Down":sourcedata[q][l]="2";break;
	    			 	case "Up":sourcedata[q][l]="3";break;
					} 
	    		 }else if(l==38)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
					} 
	    		 }else if(l==39)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
					} 
	    		 }else if(l==40)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
					} 
					
	    		 }else if(l==41)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Steady":sourcedata[q][l]="1";break;
					} 
	    		 }else if(l==42)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Ch":sourcedata[q][l]="1";break;
					} 
	    		 }else if(l==43)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "No":sourcedata[q][l]="0";break;
	    			 	case "Yes":sourcedata[q][l]="1";break;
					} 
	    		 }else if(l==44)
	    		 {
	    			 switch (sourcedata[q][l]) 
	    			 {
	    			 	case "NO": sourcedata[q][l]="0";break;
	    			 	case "<30":sourcedata[q][l]="1";break;
	    			 	case ">30":sourcedata[q][l]="2";break;
					} 
	    		 }
	    	 }
	     }
		
		for(int i=0;i<sourcedata.length-1;i++)
		{
			double b[] = new double[46];
			for(int j=0;j<sourcedata[i].length;j++)
			{
				b[j]=Double.parseDouble(sourcedata[i+1][j]);
			}
			b[45]=0;
			data.add(b);
		}
		
//		for(int i=0;i<data.size();i++)
//		{
//			for(int j=0;j<46;j++)
//			{
//				System.out.print(data.get(i)[j]+" ");
//			}
//			System.out.println();
//		}
	}

	//定义初试聚类核心点
	public static Vector<double[]> set_kernal(Vector<double[]> data,int a,int b,int c)
	{
		//设置聚类核心，a，b，c分别代表一个类的核心在data中的编号 把一个例子加到init_kernal中
		init_kernal.add(data.get(a));  
		init_kernal.add(data.get(b));  
		init_kernal.add(data.get(c));  
		return init_kernal;            
	}
	
	//迭代一次选择聚类核心点位置
	public static double choose(double[] data,double[] a,double[] b,double[] c)
	{
		double ta=0,tb=0,tc=0;
		for(int i=0;i<45;i++)
		{
			ta=ta+(data[i] - a[i]) * (data[i] - a[i]);
			tb=tb+(data[i] - b[i]) * (data[i] - b[i]);
			tc=tc+(data[i] - c[i]) * (data[i] - c[i]);
		}
		if(ta == Math.min(Math.min(ta, tb), tc))
		{
			return 1;
		}else if(tb == Math.min(Math.min(ta, tb), tc))
		{
			return 2;
		}else if(tc == Math.min(Math.min(ta, tb), tc))
		{
			return 3;
		}
        return 0;
	}
	
	
	
	public static Vector<double[]> onestep(Vector<double[]> data, Vector<double[]> kernal)
	{
		Vector<double[]> newkernal = new Vector<double[]>();
		int i = 0;
		double[] a = kernal.get(0);//取得当前第一个聚类核心的数据
		double[] b = kernal.get(1);//取得当前第二个聚类核心的数据
		double[] c = kernal.get(2);//取得当前第三个聚类核心的数据
		double[] temp;
		
		while(i<data.size())
		{
			temp=data.get(i);
			temp[45] = choose(temp,a,b,c);//选择类的类别1 2 3
			i++;
		}
		
		//用来计算总和 和 均值
		double[] suma = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};  
        int al = 0;//表示当前第一类的样本个数   无种类数值ֵ
        double[] sumb = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; 
        int bl = 0;//当前第二类的样本个数           无种类数值ڶ���������           ��������ֵ
        double[] sumc = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};  
        int cl = 0;//当前第三类的样本个数           无种类数值
        i=0;
        while(i<data.size())
        {
        	double[] t = data.get(i);
        	if(t[45] == 1.0)
        	{
        		for(int j=0;j<45;j++)//例子的前三项
        		{
        			suma[j] = suma[j] + t[j];//求同一类中的前三项的每一列的总和，为了求均值ֵ
        		}
        		al++;
        	}else if(t[45] == 2.0)
        	{
        		for(int j=0;j<45;j++)
        		{
        			sumb[j] = sumb[j] + t[j];
        		}
        		bl++;
        	}else if(t[45] == 3.0)
        	{
        		for(int j=0;j<45;j++)
        		{
        			sumc[j] = sumc[j] + t[j];
        		}
        		cl++;
        	}
        	i++;
        }
        for(int j=0;j<4;j++)
        {
        	suma[j] = suma[j] / al;
        	sumb[j] = sumb[j] / bl;
        	sumc[j] = sumc[j] / cl;
        }
        //此时，suma里面的前四个数据换成了同一类的均值  所以以均值为标准的新的聚类核心三个点又出来了
        newkernal.add(suma);//此时 suma数组中 没有第五列   那个确定类别的数值ֵ
        newkernal.add(sumb);//此时 sumb数组中 没有第五列   那个确定类别的数值ֵ
        newkernal.add(sumc);//此时 sumc数组中 没有第五列   那个确定类别的数值ֵ
		return newkernal;
	}
	
	
	public static void k_means()
	{
		while(true)
		{
			boolean con = true;
									//预处理之后的数据data    核心点数据三个
			Vector<double[]> t = onestep(data,init_kernal);//进行迭代一次，返回迭代后的新的核心让t接收
			
			for(int i=0;i<t.size();i++)
			{
				for(int j=0;j<4;j++)
				{
					if(t.get(i)[j] != init_kernal.get(i)[j])
					{
						con=false;
					}
				}
			}
			if(con==true)
			{
				break;
			}else
			{
				init_kernal = t;
			}
		}
	}
	
	
	
	public static void show_category(Vector<double[]> data)
	{
		String [][] str = new String[data.size()][46];
		//for1
		for(int i=0;i<data.size();i++)
		{
			for (int j = 0; j < 46; j++) 
			{  
                str[i][j]=Double.toString(data.get(i)[j]); 
            }  
		}//for1
		
		//for2
		for(int i=0;i<str.length;i++)
		{
			for(int j=0;j<46;j++)
			{
				if(j==2)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="?";break;
						case "1.0":str[i][j]="Caucasian";break;
						case "2.0":str[i][j]="AfricanAmerican";break;
						case "3.0":str[i][j]="Other";break;
						case "4.0":str[i][j]="Asian";break;
						case "5.0":str[i][j]="Hispanic";break;
					}
				}else if(j==3)
				{
					switch(str[i][j])
					{
						case "-1.0":str[i][j]="Unknown/Invalid";break;
						case "0.0":str[i][j]="?";break;
						case "1.0":str[i][j]="Female";break;
						case "2.0":str[i][j]="Male";break;
					}
				}else if(j==4)
				{
					switch(str[i][j])
					{
						case "1.0":str[i][j]="[0-10)";break;
						case "2.0":str[i][j]="[10-20)";break;
						case "3.0":str[i][j]="[20-30)";break;
						case "4.0":str[i][j]="[30-40)";break;
						case "5.0":str[i][j]="[40-50)";break;
						case "6.0":str[i][j]="[50-60)";break;
						case "7.0":str[i][j]="[60-70)";break;
						case "8.0":str[i][j]="[70-80)";break;
						case "9.0":str[i][j]="[80-90)";break;
						case "10.0":str[i][j]="[90-100)";break;
					}
				}else if(j==5)
				{
					switch(str[i][j])
					{
						case "1.0":str[i][j]="Emergency";break;
						case "2.0":str[i][j]="Urgent";break;
						case "3.0":str[i][j]="Elective";break;
						case "4.0":str[i][j]="Newborn";break;
						case "5.0":str[i][j]="Not Available";break;
						case "6.0":str[i][j]="NULL";break;
						case "7.0":str[i][j]="Trauma Center";break;
						case "8.0":str[i][j]="Not Mapped";break;
					}
				}else if(j==6)
				{
					switch(str[i][j])
					{
						case "1.0":str[i][j]="Discharged to home";break;
						case "2.0":str[i][j]="Discharged/transferred to another short term hospital";break;
						case "3.0":str[i][j]="Discharged/transferred to SNF";break;
						case "4.0":str[i][j]="Discharged/transferred to ICF";break;
						case "5.0":str[i][j]="Discharged/transferred to another type of inpatient care institution";break;
						case "6.0":str[i][j]="Discharged/transferred to home with home health service";break;
						case "7.0":str[i][j]="Left AMA";break;
						case "8.0":str[i][j]="Discharged/transferred to home under care of Home IV provider";break;
						case "9.0":str[i][j]="Admitted as an inpatient to this hospital";break;
						case "10.0":str[i][j]="Neonate discharged to another hospital for neonatal aftercare";break;
						case "11.0":str[i][j]="Expired";break;
						case "12.0":str[i][j]="Still patient or expected to return for outpatient services";break;
						case "13.0":str[i][j]="Hospice / home";break;
						case "14.0":str[i][j]="Hospice / medical facility";break;
						case "15.0":str[i][j]="Discharged/transferred within this institution to Medicare approved swing bed";break;
						case "16.0":str[i][j]="Discharged/transferred/referred another institution for outpatient services";break;
						case "17.0":str[i][j]="Discharged/transferred/referred to this institution for outpatient services";break;
						case "18.0":str[i][j]="NULL";break;
						case "19.0":str[i][j]="Expired at home. Medicaid only, hospice";break;
						case "20.0":str[i][j]="Expired in a medical facility. Medicaid only, hospice";break;
						case "21.0":str[i][j]="Expired, place unknown. Medicaid only, hospice";break;
						case "22.0":str[i][j]="Discharged/transferred to another rehab fac including rehab units of a hospital";break;
						case "23.0":str[i][j]="Discharged/transferred to a long term care hospital";break;
						case "24.0":str[i][j]="Discharged/transferred to a nursing facility certified under Medicaid but not certified under Medicare";break;
						case "25.0":str[i][j]="Not Mapped";break;
						case "26.0":str[i][j]="Unknown/Invalid";break;
						case "27.0":str[i][j]="Discharged/transferred to a federal health care facility";break;
						case "28.0":str[i][j]="Discharged/transferred/referred to a psychiatric hospital of psychiatric distinct part unit of a hospital";break;
						case "29.0":str[i][j]="Discharged/transferred to a Critical Access Hospital (CAH)";break;
						case "30.0":str[i][j]="Discharged/transferred to another Type of Health Care Institution not Defined Elsewhere";break;
					}
				}else if(j==7)
				{
					switch(str[i][j])
					{
						case "1.0":str[i][j]="Physician Referral";break;
						case "2.0":str[i][j]="Clinic Referral";break;
						case "3.0":str[i][j]="HMO Referral";break;
						case "4.0":str[i][j]="Transfer from a hospital";break;
						case "5.0":str[i][j]="Transfer from a Skilled Nursing Facility (SNF)";break;
						case "6.0":str[i][j]="Transfer from another health care facility";break;
						case "7.0":str[i][j]="Emergency Room";break;
						case "8.0":str[i][j]="Court/Law Enforcement";break;
						case "9.0":str[i][j]="Not Available";break;
						case "10.0":str[i][j]="Transfer from critial access hospital";break;
						case "11.0":str[i][j]="Normal Delivery";break;
						case "12.0":str[i][j]="Premature Delivery";break;
						case "13.0":str[i][j]="Sick Baby";break;
						case "14.0":str[i][j]="Extramural Birth";break;
						case "15.0":str[i][j]="Not Available";break;
						case "16.0":str[i][j]="NULL";break;
						case "17.0":str[i][j]="Transfer From Another Home Health Agency";break;
						case "18.0":str[i][j]="Readmission to Same Home Health Agency";break;
						case "19.0":str[i][j]="Not Mapped";break;
						case "20.0":str[i][j]="Unknown/Invalid";break;
						case "21.0":str[i][j]="Transfer from hospital inpt/same fac reslt in a sep claim";break;
						case "22.0":str[i][j]="Born inside this hospital";break;
						case "23.0":str[i][j]="Born outside this hospital";break;
						case "24.0":str[i][j]="Transfer from Ambulatory Surgery Center";break;
						case "25.0":str[i][j]="Transfer from Hospice";break;
					}
				}else if(j==9)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="?";break;
						case "1.0":str[i][j]="AllergyandImmunology";break;
						case "2.0":str[i][j]="Anesthesiology";break;
						case "3.0":str[i][j]="Anesthesiology-Pediatric";break;
						case "4.0":str[i][j]="Cardiology";break;
						case "5.0":str[i][j]="Cardiology-Pediatric";break;
						case "6.0":str[i][j]="DCPTEAM";break;
						case "7.0":str[i][j]="Dentistry";break;
						case "8.0":str[i][j]="Dermatology";break;
						case "9.0":str[i][j]="Emergency/Trauma";break;
						case "10.0":str[i][j]="Endocrinology";break;
						case "11.0":str[i][j]="Endocrinology-Metabolism";break;
						case "12.0":str[i][j]="Family/GeneralPractice";break;
						case "13.0":str[i][j]="Gastroenterology";break;
						case "14.0":str[i][j]="Gynecology";break;
						case "15.0":str[i][j]="Hematology";break;
						case "16.0":str[i][j]="Hematology/Oncology";break;
						case "17.0":str[i][j]="Hospitalist";break;
						case "18.0":str[i][j]="InfectiousDiseases";break;
						case "19.0":str[i][j]="InternalMedicine";break;
						case "20.0":str[i][j]="Nephrology";break;
						case "21.0":str[i][j]="Neurology";break;
						case "22.0":str[i][j]="Neurophysiology";break;
						case "23.0":str[i][j]="Obsterics&Gynecology-GynecologicOnco";break;
						case "24.0":str[i][j]="Obstetrics";break;
						case "25.0":str[i][j]="ObstetricsandGynecology";break;
						case "26.0":str[i][j]="Oncology";break;
						case "27.0":str[i][j]="Ophthalmology";break;
						case "28.0":str[i][j]="Orthopedics";break;
						case "29.0":str[i][j]="Orthopedics-Reconstructive";break;
						case "30.0":str[i][j]="Osteopath";break;
						case "31.0":str[i][j]="Otolaryngology";break;
						case "32.0":str[i][j]="OutreachServices";break;
						case "33.0":str[i][j]="Pathology";break;
						case "34.0":str[i][j]="Pediatrics";break;
						case "35.0":str[i][j]="Pediatrics-AllergyandImmunology";break;
						case "36.0":str[i][j]="Pediatrics-CriticalCare";break;
						case "37.0":str[i][j]="Pediatrics-EmergencyMedicine";break;
						case "38.0":str[i][j]="Pediatrics-Endocrinology";break;
						case "39.0":str[i][j]="Pediatrics-Hematology-Oncology";break;
						case "40.0":str[i][j]="Pediatrics-InfectiousDiseases";break;
						case "41.0":str[i][j]="Pediatrics-Neurology";break;
						case "42.0":str[i][j]="Pediatrics-Pulmonology";break;
						case "43.0":str[i][j]="Perinatology";break;
						case "44.0":str[i][j]="PhysicalMedicineandRehabilitation";break;
						case "45.0":str[i][j]="PhysicianNotFound";break;
						case "46.0":str[i][j]="Podiatry";break;
						case "47.0":str[i][j]="Proctology";break;
						case "48.0":str[i][j]="Psychiatry";break;
						case "49.0":str[i][j]="Psychiatry-Addictive";break;
						case "50.0":str[i][j]="Psychiatry-Child/Adolescent";break;
						case "51.0":str[i][j]="Psychology";break;
						case "52.0":str[i][j]="Pulmonology";break;
						case "53.0":str[i][j]="Radiologist";break;
						case "54.0":str[i][j]="Radiology";break;
						case "55.0":str[i][j]="Resident";break;
						case "56.0":str[i][j]="Rheumatology";break;
						case "57.0":str[i][j]="Speech";break;
						case "58.0":str[i][j]="SportsMedicine";break;
						case "59.0":str[i][j]="Surgeon";break;
						case "60.0":str[i][j]="Surgery-Cardiovascular";break;
						case "61.0":str[i][j]="Surgery-Cardiovascular/Thoracic";break;
						case "62.0":str[i][j]="Surgery-Colon&Rectal";break;
						case "63.0":str[i][j]="Surgery-General";break;
						case "64.0":str[i][j]="Surgery-Maxillofacial";break;
						case "65.0":str[i][j]="Surgery-Neuro";break;
						case "66.0":str[i][j]="Surgery-Pediatric";break;
						case "67.0":str[i][j]="Surgery-Plastic";break;
						case "68.0":str[i][j]="Surgery-PlasticwithinHeadandNeck";break;
						case "69.0":str[i][j]="Surgery-Thoracic";break;
						case "70.0":str[i][j]="Surgery-Vascular";break;
						case "71.0":str[i][j]="SurgicalSpecialty";break;
						case "72.0":str[i][j]="Urology";break;
					}
				}else if(j==17)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="None";break;
						case "1.0":str[i][j]="Norm";break;
						case "2.0":str[i][j]=">200";break;
						case "3.0":str[i][j]=">300";break;
					}
				}else if(j==18)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="None";break;
						case "1.0":str[i][j]="Norm";break;
						case "2.0":str[i][j]=">7";break;
						case "3.0":str[i][j]=">8";break;
					}
				}else if(j==19)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
						case "2.0":str[i][j]="Down";break;
						case "3.0":str[i][j]="Up";break;
					}
				}else if(j==20)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
						case "2.0":str[i][j]="Down";break;
						case "3.0":str[i][j]="Up";break;
					}
				}else if(j==21)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
						case "2.0":str[i][j]="Down";break;
						case "3.0":str[i][j]="Up";break;
					}
				}else if(j==22)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
						case "2.0":str[i][j]="Down";break;
						case "3.0":str[i][j]="Up";break;
					}
				}else if(j==23)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
						case "2.0":str[i][j]="Down";break;
						case "3.0":str[i][j]="Up";break;
					}
				}else if(j==24)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
					}
				}else if(j==25)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
						case "2.0":str[i][j]="Down";break;
						case "3.0":str[i][j]="Up";break;
					}
				}else if(j==26)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
						case "2.0":str[i][j]="Down";break;
						case "3.0":str[i][j]="Up";break;
					}
				}else if(j==27)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
					}
				}else if(j==28)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
						case "2.0":str[i][j]="Down";break;
						case "3.0":str[i][j]="Up";break;
					}
				}else if(j==29)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
						case "2.0":str[i][j]="Down";break;
						case "3.0":str[i][j]="Up";break;
					}
				}else if(j==30)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
						case "2.0":str[i][j]="Down";break;
						case "3.0":str[i][j]="Up";break;
					}
				}else if(j==31)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
						case "2.0":str[i][j]="Down";break;
						case "3.0":str[i][j]="Up";break;
					}
				}else if(j==32)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
					}
				}else if(j==33)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
						case "2.0":str[i][j]="Up";break;
					}
				}else if(j==34)
				{
					str[i][j]="No";break;
				}else if(j==35)
				{
					str[i][j]="No";break;
				}else if(j==36)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
						case "2.0":str[i][j]="Down";break;
						case "3.0":str[i][j]="Up";break;
					}
				}else if(j==37)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
						case "2.0":str[i][j]="Down";break;
						case "3.0":str[i][j]="Up";break;
					}
				}else if(j==38)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
					}
				}else if(j==39)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
					}
				}else if(j==40)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
					}
				}else if(j==41)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Steady";break;
					}
				}else if(j==42)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Ch";break;
					}
				}else if(j==43)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="Yes";break;
					}
				}else if(j==44)
				{
					switch(str[i][j])
					{
						case "0.0":str[i][j]="No";break;
						case "1.0":str[i][j]="<30";break;
						case "2.0":str[i][j]=">30";break;
					}
				}
			}
		}//for2
		
		
//		//for3
//		for(int i=0;i<str.length;i++)
//		{
//			for(int j=0;j<str[i].length;j++)
//			{
//				System.out.print(str[i][j]+"   ");
//			}
//			System.out.println();
//		}//for3
		
		File writename = new File("D:\\output1.txt"); 
        try {
			writename.createNewFile();
			BufferedWriter out = new BufferedWriter(new FileWriter(writename));
			for(int i=0;i<45;i++)
	        {
	       	 out.write(sourcedata[0][i]+"   ");
	        }
			out.write("\r\n");
			
			for(int i=0;i<str.length;i++)
			{
				for (int j = 0; j < 46; j++) 
					{  
		                out.write(str[i][j] + "    ");
		            } 
				out.write("\r\n");
			}
	        out.flush(); 
	        out.close(); 
		} catch (IOException e) {
			e.printStackTrace();
		} 
		
	}
	
	
	public static void main(String[] args) 
	{
		ReadFile.loadData("F:/data.txt");
		ReadFile.preparement(sourcedata);
		set_kernal(data, 30000,60000,80000);
		k_means();
		show_category(data);
		
		for(int i=0;i<init_kernal.size();i++){
			System.out.println("第" + (i+1) + "个聚类中心点为： ");
			for(int j=0;j<45;j++){
				System.out.print(df.format(init_kernal.get(i)[j])+"   ");
			}
			System.out.println();
		}
		
	}
}
