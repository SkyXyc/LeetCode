package problem1to10;

public class Problem11 {//accept
	public static int maxArea(int[] height) {
		int size = height.length;
		int begin = 0;
		int end = size-1;
		int maxArea = 0;
		int temp = 0;

		
		if(size < 2||height == null){
			return 0;
		}
		
		while(begin!=end){//若begin,end为最大值的首尾坐标，则可得出begin前不存在比begin高的垂线，同理，end后不存在比end高的垂线，所以从两端开始向内遍历
			if(height[begin]>height[end]){
				temp = (end-begin)*height[end];
				end--;
			}else{
				temp = (end-begin)*height[begin];
				begin++;
			}
			
			if(temp>=maxArea){
				maxArea = temp;
			}
		}
		
		return maxArea;
	}
	
	public static void main(String[] args){
		int[] ints = {5,2,6,7,3};
		int maxSize = maxArea(ints);
		System.out.println(maxSize);
	}
}
