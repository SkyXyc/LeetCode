package problem1to10;

public class Problem14 {
	 public String longestCommonPrefix(String[] strs) {
	        boolean flag = true;
	        int minlength = strs[0].length();
	        char ch ;
	        String res = new String("");
	        for(int i=0;i<strs.length;i++){
	            if(strs[i].length()<minlength){
	                minlength = strs[i].length();
	            }
	        }
	        
	        for(int i=0;i<minlength;i++){
	            ch = strs[0].charAt(i);
	            for(String str:strs){
	                if(str.charAt(i) != ch){
	                    return res;
	                }
	            }
	            res += ch;
	        }
	        return res;
	    }
}
