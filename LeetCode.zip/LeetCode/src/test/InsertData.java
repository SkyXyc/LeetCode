package test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

public class InsertData {
	public static void insert(File file) throws FileNotFoundException{
		  java.util.Random r=new java.util.Random(); 
		  FileOutputStream fs = new FileOutputStream(file);
		  
		  PrintStream p = new PrintStream(fs);
		  for(int j=0;j<100;j++){
			  for(int i=0;i<1;i++){ 
				  p.printf("%.1f",r.nextFloat()/2);
				  //p.print(",");
			 }
			  
			 //p.printf("%.1f",r.nextFloat()/2);
			 p.println();
		}
		
		 p.close();
	}
	
	public static void main(String[] args){
		File file = new File("F:/Data5.txt");
		try {
			insert(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("输出完成");
	}
}
